from setuptools import setup

setup(name='probabi_distributions',
	version='1.0',
	description='Gaussian and Binomial distributions',
	packages=['probabi_distributions'],
	author= 'Darshit Sharma',
	zip_safe=False)